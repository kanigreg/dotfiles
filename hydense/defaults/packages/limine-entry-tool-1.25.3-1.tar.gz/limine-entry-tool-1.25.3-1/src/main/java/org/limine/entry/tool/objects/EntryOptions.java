package org.limine.entry.tool.objects;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EntryOptions {

    private String machineID = null;
    private int orderPriority = Config.DEFAULT_ORDER_PRIORITY_VALUE;
    private boolean entryOverwrite = Config.DEFAULT_ENTRY_OVERWRITE;

    public void parseComment(String comment) {
        // Check for null or empty comment
        if (comment == null || comment.isBlank()) {
            return;
        }

        comment = comment.toLowerCase();

        // Regex for machine-ID
        Pattern machineIdPattern = Pattern.compile(Key.MACHINE_ID + "([a-f0-9]{32})");
        Matcher machineIdMatcher = machineIdPattern.matcher(comment);

        // Extract machine-ID, if available
        if (machineIdMatcher.find()) {
            this.machineID = machineIdMatcher.group(1);
        }

        // Regex for order-priority
        Pattern orderPriorityPattern = Pattern.compile(Key.ORDER_PRIORITY + "(\\d{1,8})");
        Matcher orderPriorityMatcher = orderPriorityPattern.matcher(comment);

        // Extract order-priority, if available
        if (orderPriorityMatcher.find()) {
            this.orderPriority = Integer.parseInt(orderPriorityMatcher.group(1));
        }
    }

    public boolean parseArg(String arg, Key optionName) {
        if (Key.ORDER_PRIORITY.equals(optionName)) {
            // Regex for order-priority
            Pattern orderPriorityPattern = Pattern.compile("(\\d{1,8})");
            Matcher orderPriorityMatcher = orderPriorityPattern.matcher(arg);
            // Extract order-priority, if available
            if (orderPriorityMatcher.find()) {
                orderPriority = Integer.parseInt(orderPriorityMatcher.group(1));
                return true;
            } else {
                return false;
            }
        }
        return false;
    }

    public int getPriority() {
        return this.orderPriority;
    }

    public EntryOptions setPriority(int priority) {
        this.orderPriority = priority;
        return this;
    }

    public String getMachineID() {
        return this.machineID;
    }

    public EntryOptions setMachineID(String machineID) {
        this.machineID = machineID;
        return this;
    }

    public boolean getEntryOverwrite() {
        return this.entryOverwrite;
    }

    public EntryOptions setEntryOverwrite(boolean entryOverwrite) {
        this.entryOverwrite = entryOverwrite;
        return this;
    }

    public String buildEntryComment() {
        StringBuilder comment = new StringBuilder();
        if (this.machineID != null) {
            comment.append(Key.MACHINE_ID).append(this.machineID).append(" ");
        }
        comment.append(Key.ORDER_PRIORITY).append(this.orderPriority).append(" ");
        return comment.toString();
    }

    public enum Key {
        MACHINE_ID("machine-id="),
        ORDER_PRIORITY("order-priority=");

        private final String key;

        Key(String key) {
            this.key = key;
        }

        @Override
        public String toString() {
            return this.key;
        }
    }
}
