package org.limine.entry.tool.formats.limine8;

public enum Limine {
    PATH("path:"),
    MODULE_PATH("module_path:"),
    IMAGE_PATH("image_path:"),
    KERNEL_PATH("kernel_path:"),
    KERNEL_CMDLINE("kernel_cmdline:"),
    CMDLINE("cmdline:"),
    DEFAULT_PATH_FUNCTION("boot():"),
    PROTOCOL("protocol:"),
    PROTOCOL_EFI("efi"),
    PROTOCOL_UEFI("uefi"),
    PROTOCOL_EFI_CHAINLOAD("efi_chainload"),
    PROTOCOL_LINUX("linux"),
    PROTOCOL_LIMINE("limine"),
    COMMENT("comment:"),
    ENTRY_KEY("/"),
    SUB_ENTRY_KEY("//"),
    SUB_X2_ENTRY_KEY("///"),
    SUB_X3_ENTRY_KEY("////"),
    EXPAND("+"),
    HASH("#"),
    PATH_RESOURCE_PATTERN("boot\\(\\d*\\):|guid\\([^)]*\\):|hdd\\(\\d+:\\d*\\):|odd\\(\\d+:\\d*\\):|uuid\\([^)]*\\):"),
    HASH_PATTERN("#[a-fA-F0-9]*"); // Blake2 hash pattern (64 hex chars)


    private final String key;

    Limine(String key) {
        this.key = key;
    }

    /**
     * Extracts the value from a string formatted as "<key>: value".
     *
     * @param input The input string in the format "<key>: value".
     * @return The value after the key and colon, or an empty string if the format is invalid.
     */
    public static String extractValue(String input) {
        // Check if the input string is valid
        if (input == null) {
            return "";
        }

        // Find the index of the colon
        int colonIndex = input.indexOf(':');

        // Extract the substring after the colon
        return input.substring(colonIndex + 1).trim();
    }

    @Override
    public String toString() {
        return this.key;
    }
}