package org.limine.entry.tool.processes;

import org.limine.entry.tool.objects.Config;
import org.limine.entry.tool.objects.TreeNode;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

import static org.limine.entry.tool.processes.Utility.*;

public record LimineWriter(Config config) {

    public static void createDefaultLimineConfigFile(String filePath) throws IOException {
        Path path = Paths.get(filePath);
        // Ensure the parent directory exists
        if (Files.notExists(path.getParent())) {
            Files.createDirectories(path.getParent());
        }
        // Write the default content to the configuration file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(path.toFile()))) {
            writer.write("""
                    ### Read more at config document: https://codeberg.org/Limine/Limine/src/branch/v9.x/CONFIG.md
                    #timeout: 3
                    ### Note: For "default_entry" to select a sub-entry within an OS menu, modify "/OS name" to "/+OS name" to keep its submenus visible.
                    default_entry: 2
                    #interface_branding: Your boot manager
                    #interface_branding_color: 3
                    hash_mismatch_panic: no
                    \s
                    \s
                    """);
        }
    }

    /**
     * Back up limine.conf
     */
    public void backup() {
        String limineConfigFilePath = Utility.buildPath(config.espPath(), Config.LIMINE_CONFIG_FILE);
        if (Utility.isFilePresent(limineConfigFilePath)) {
            // Auto time-based backup. Check if an older backup exists.
            String backupPath = limineConfigFilePath + Config.BACKUP_SUFFIX;
            boolean isBackupNeeded = true;
            if (Utility.isFilePresent(backupPath)) {
                isBackupNeeded = Utility.isFileOlderThan(backupPath, Config.CONFIG_BACKUP_THRESHOLD);
            }
            if (isBackupNeeded) {
                Utility.copyFile(limineConfigFilePath, backupPath, true, false, false);
            }
        }
    }

    public void save(TreeNode rootNode) {
        List<String> lines = new ArrayList<>();
        this.writeNodeToLines(rootNode, lines, 0);

        String limineConfigPath = Utility.buildPath(config.espPath(), Config.LIMINE_CONFIG_FILE);
        Path limineTmpConfigPath = Paths.get(limineConfigPath + ".tmp");

        // Check if "$ESP_PATH/limine.conf" exists.
        if (!Utility.isFilePresent(limineConfigPath)) {
            exitWithError("File path: " + limineConfigPath + " does not exit!");
            return;
        }

        try {
            Files.write(limineTmpConfigPath, lines, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            Utility.runCommand("sync -f " + limineTmpConfigPath, false, false);
            Utility.moveFile(limineTmpConfigPath.toString(), limineConfigPath, true, false, false);
            infoMessage("Updated:", limineConfigPath);
        } catch (IOException e) {
            errorMessage("Failed to write:", limineConfigPath);
            exitWithError("Reason:", e.getMessage());
        }
    }

    private void writeNodeToLines(TreeNode node, List<String> lines, int depth) {
        if (depth > 0) {
            lines.add(node.getName());
        }
        lines.addAll(node.getConfigLines());
        for (TreeNode childNode : node.getNodes()) {
            writeNodeToLines(childNode, lines, depth + 1);
        }
        if (node.isEnableLineBreak()) {
            lines.add("");
        }
    }
}


