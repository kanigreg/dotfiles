package org.limine.entry.tool.processes;

import org.limine.entry.tool.formats.limine8.Limine;
import org.limine.entry.tool.formats.limine8.LimineEntry;
import org.limine.entry.tool.objects.Config;
import org.limine.entry.tool.objects.EntryOptions;
import org.limine.entry.tool.objects.TreeNode;

import java.io.File;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.limine.entry.tool.processes.Utility.errorMessage;

public class LimineManager {

    private final TreeNode targetOsNode;
    private final Config config;
    public boolean isUpdateNeeded;

    public LimineManager(TreeNode targetOsNode, Config config) {
        this.targetOsNode = targetOsNode;
        this.config = config;
        this.isUpdateNeeded = false;
    }

    public static boolean merge(TreeNode rootNode, String efiName, String comment, EntryOptions entryOptions, String efiFilePath, Config config) {
        // Check if efiFilePath is valid
        efiFilePath = Utility.correctCaseSensitivePath(efiFilePath);
        if (efiFilePath == null) {
            return false;
        }
        String mountPoint = Utility.getMountPointIfFat32(efiFilePath);
        if (mountPoint.isEmpty()) {
            return false;
        }
        String pathFunction;
        if (Objects.equals(Utility.removeSurroundingSlashes(mountPoint), Utility.removeSurroundingSlashes(config.espPath()))) {
            pathFunction = Limine.DEFAULT_PATH_FUNCTION.toString();
        } else {
            pathFunction = "guid(" + Utility.getPartitionUUID(mountPoint) + "):";
        }
        TreeNode efiNode = rootNode.findNodeByCleanName(efiName, null, 1);
        if (efiNode == null) {
            efiNode = new TreeNode(Limine.ENTRY_KEY + efiName, 1, rootNode.getName());
            efiNode.setEnableLineBreak(true);
            int position = rootNode.findPositionByLowerPriority(entryOptions.getPriority());
            rootNode.addNode(position, efiNode);
        } else if (entryOptions.getEntryOverwrite()) {
            efiNode.getConfigLines().clear();
        } else {
            return false;
        }
        List<String> lines = List.of(
                Limine.COMMENT + " " + comment,
                Limine.COMMENT + " " + entryOptions.buildEntryComment(),
                Limine.PROTOCOL + " " + Limine.PROTOCOL_EFI_CHAINLOAD,
                Limine.IMAGE_PATH + " " + pathFunction + efiFilePath.substring(mountPoint.length()),
                ""
        );
        efiNode.getConfigLines().addAll(lines);
        return true;
    }

    public static boolean removeEfi(TreeNode rootNode, String efiFilePath, Config config) {
        if (efiFilePath == null || efiFilePath.isBlank()) {
            return false;
        }
        // Do not check efiFilePath existence here:
        // a matching EFI boot entry should be removed even if the file is missing.
        String correctPath = Utility.correctCaseSensitivePath(efiFilePath);
        if (correctPath != null) {
            efiFilePath = correctPath;
        }
        String mountPoint = Utility.getMountPointIfFat32(efiFilePath);
        if (mountPoint.isEmpty()) {
            return false;
        }
        String pathFunction = null;
        if (Objects.equals(Utility.removeSurroundingSlashes(mountPoint), Utility.removeSurroundingSlashes(config.espPath()))) {
            pathFunction = Limine.DEFAULT_PATH_FUNCTION.toString();
        }

        String gptUuid = null;
        if (Utility.isSystemEfi()) {
            gptUuid = Utility.getPartitionUUID(mountPoint);
        }

        if (pathFunction == null && gptUuid == null) {
            return false;
        }

        String espFilePath = efiFilePath.substring(mountPoint.length());
        Iterator<TreeNode> it = rootNode.getNodes().iterator();
        boolean isUpdateNeeded = false;
        while (it.hasNext()) {
            // Translate the TreeNode into a new LimineEntry
            LimineEntry entry = new LimineEntry(it.next());
            if (entry.containsEfiPath(pathFunction, espFilePath) || entry.containsEfiPath(gptUuid, espFilePath)) {
                it.remove();
                isUpdateNeeded = true;
                break;
            }
        }
        return isUpdateNeeded;
    }

    public static boolean removeOs(TreeNode rootNode, String osNameOrMachineID, Config config) {
        if (osNameOrMachineID == null || osNameOrMachineID.isBlank()) {
            return false;
        }
        // Regex for machine-ID
        Matcher machineIdMatcher = Pattern.compile("([a-f0-9]{32})").matcher(osNameOrMachineID);

        TreeNode osNode;
        // Extract machine-ID, if available
        if (machineIdMatcher.find()) {
            osNode = rootNode.findNodeByMachineID(osNameOrMachineID, 1);
        } else {
            osNode = rootNode.findNodeByCleanName(osNameOrMachineID, null, 1);
        }
        boolean isUpdateNeeded = false;
        if (osNode != null) {
            rootNode.getNodes().remove(osNode);
            isUpdateNeeded = true;
        }
        return isUpdateNeeded;
    }

    /**
     * Adds an initramfs and vmlinuz to the Limine boot entries.
     */
    public void add(String kernelName, String kernelComment, EntryOptions kernelEntryOptions, String initramfsPath, String vmlinuzPath, String suffixName) {

        if (!Utility.isFilePresent(initramfsPath)) {
            errorMessage("The file: " + initramfsPath + " is not found");
            return;
        }
        if (!Utility.isFilePresent(vmlinuzPath)) {
            errorMessage("The file: " + vmlinuzPath + " is not found");
            return;
        }

        String dirPath = Utility.buildPath(config.espPath(), config.machineID(), kernelName) + File.separator;
        Utility.ensureDirectoryExists(dirPath);

        // Copying initramfs and vmlinuz to $ESP_PATH/${machine_id}/${kernel-version}/*
        String initramfsFileName = Utility.extractFileNameFromPath(initramfsPath.trim());
        String targetInitramfsPath = dirPath + initramfsFileName;

        String vmlinuzFileName = Utility.extractFileNameFromPath(vmlinuzPath.trim());
        String targetVmlinuzPath = dirPath + vmlinuzFileName;

        if (Utility.isFilePresent(targetInitramfsPath)) {
            String hashCode = Utility.computeBlake2(initramfsPath);
            String targetHashCode = Utility.computeBlake2(targetInitramfsPath);
            if (!hashCode.equals(targetHashCode)) {
                Utility.copyFile(initramfsPath, targetInitramfsPath, true);
            }
        } else {
            Utility.copyFile(initramfsPath, targetInitramfsPath, true);
        }

        if (Utility.isFilePresent(targetVmlinuzPath)) {
            String hashCode = Utility.computeBlake2(vmlinuzPath);
            String targetHashCode = Utility.computeBlake2(targetVmlinuzPath);
            if (!hashCode.equals(targetHashCode)) {
                Utility.copyFile(vmlinuzPath, targetVmlinuzPath, true);
            }
        } else {
            Utility.copyFile(vmlinuzPath, targetVmlinuzPath, true);
        }

        boolean isKernelFound = false;
        String bootEntryName = Limine.SUB_ENTRY_KEY + kernelName + suffixName;
        List<String> comments = List.of(kernelComment);
        String kernelCmdline = config.getKernelCmdline(kernelName + suffixName);

        for (TreeNode bootNode : this.targetOsNode.getNodes()) {
            // Check if the kernelVersion exists in the OS node.
            // If so, then update the config lines for the kernel.
            if (bootNode.getName().endsWith(bootEntryName)) {
                // Update initramfs and vmlinuz
                List<String> bootConfig = this.createBootConfig(kernelName, comments, kernelCmdline, initramfsFileName, vmlinuzFileName);
                bootNode.getConfigLines().clear();
                bootNode.getConfigLines().addAll(bootConfig);
                isKernelFound = true;
                break;
            }
        }

        // The matched kernel name is not found, then add the kernel entry.
        if (!isKernelFound) {
            TreeNode bootNode = new TreeNode(Config.SPACES + bootEntryName, 2, targetOsNode.getName());
            bootNode.setOptions(kernelEntryOptions);
            List<String> bootConfig = this.createBootConfig(kernelName, comments, kernelCmdline, initramfsFileName, vmlinuzFileName);
            bootNode.getConfigLines().addAll(bootConfig);
            targetOsNode.addNode(bootNode);
        }

        // Sort boot entries based on the BOOT_ORDER
        this.sortEntriesByBootOrder(targetOsNode.getNodes(), Config.BOOT_ORDER);
        this.isUpdateNeeded = true;
    }

    /**
     * Adding a UKI (Unified kernel image) to the Limine boot entries.
     */
    public void addUki(String kernelName, String kernelComment, EntryOptions kernelEntryOptions, String ukiFilePath) {

        if (!Utility.isFilePresent(ukiFilePath)) {
            errorMessage("The file: " + ukiFilePath + " is not found");
            return;
        }

        String dirPath = Utility.buildPath(config.espPath(), Config.DEFAULT_UKI_DIR_PATH) + File.separator;
        Utility.ensureDirectoryExists(dirPath);

        // Copying ukiFilePath to $ESP_PATH/EFI/Linux/${UKI_FILE_PREFIX}_${kernel_name}.efi
        String ukiFileName = this.getDefaultUkiFileName(kernelName);
        String targetUkiPath = dirPath + ukiFileName;
        if (Utility.isFilePresent(targetUkiPath)) {
            String hashCode = Utility.computeBlake2(ukiFilePath);
            String targetHashCode = Utility.computeBlake2(targetUkiPath);
            if (!hashCode.isEmpty() && !hashCode.equals(targetHashCode)) {
                Utility.copyFile(ukiFilePath, targetUkiPath, true);
            }
        } else {
            Utility.copyFile(ukiFilePath, targetUkiPath, true);
        }

        boolean isKernelFound = false;
        String bootEntryName = Limine.SUB_ENTRY_KEY + kernelName;
        List<String> comments = List.of(kernelComment);
        String kernelCmdline = config.getKernelCmdline(kernelName);

        for (TreeNode bootNode : this.targetOsNode.getNodes()) {
            // Check if the UKI entry exists in the OS node. If so, then update the config lines for the kernel.
            if (bootNode.getName().endsWith(bootEntryName)) {
                // Update UKI
                List<String> bootConfig = this.createUkiBootConfig(comments, kernelCmdline, ukiFileName);
                bootNode.getConfigLines().clear();
                bootNode.getConfigLines().addAll(bootConfig);
                isKernelFound = true;
                break;
            }
        }

        // The matched kernel name is not found, then add the UKI entry.
        if (!isKernelFound) {
            TreeNode bootNode = new TreeNode(Config.SPACES + bootEntryName, 2, targetOsNode.getName());
            bootNode.setOptions(kernelEntryOptions);
            List<String> bootConfig = this.createUkiBootConfig(comments, kernelCmdline, ukiFileName);
            bootNode.getConfigLines().addAll(bootConfig);
            targetOsNode.addNode(bootNode);
        }
        this.sortEntriesByBootOrder(targetOsNode.getNodes(), Config.BOOT_ORDER);
        this.isUpdateNeeded = true;
    }

    private List<String> createBootConfig(String kernelName, List<String> kernelComments, String kernelCmdline, String initramfsFileName, String vmlinuzFileName) {
        String initramfsFullPath = Utility.buildPath(config.espPath(), config.machineID(), kernelName, initramfsFileName);
        initramfsFullPath = Utility.correctCaseSensitivePath(initramfsFullPath);

        String vmlinuzFullPath = Utility.buildPath(config.espPath(), config.machineID(), kernelName, vmlinuzFileName);
        vmlinuzFullPath = Utility.correctCaseSensitivePath(vmlinuzFullPath);

        String espPath = Utility.buildPath(config.espPath());
        assert initramfsFullPath != null;
        String initramfsEspPath = initramfsFullPath.substring(espPath.length());
        assert vmlinuzFullPath != null;
        String vmlinuzEspPath = vmlinuzFullPath.substring(espPath.length());

        List<String> bootConfig = new ArrayList<>();
        for (String comment : kernelComments) {
            if (!comment.isBlank()) {
                bootConfig.add(Config.SPACES + Limine.COMMENT + " " + comment);
            }
        }
        if (Utility.isSystemAmd64()) {
            bootConfig.add(Config.SPACES + Limine.PROTOCOL + " " + Limine.PROTOCOL_LINUX);
        } else {
            //TODO need to test various ARM- or RISC-V-based devices
            //bootConfig.add(Config.SPACES + Limine.PROTOCOL + " " + Limine.PROTOCOL_LIMINE);
            bootConfig.add(Config.SPACES + Limine.PROTOCOL + " " + Limine.PROTOCOL_LINUX);
        }
        bootConfig.add(Config.SPACES + Limine.MODULE_PATH + " " + config.pathFunction() + initramfsEspPath + this.b2sum(initramfsFullPath));
        bootConfig.add(Config.SPACES + Limine.KERNEL_PATH + " " + config.pathFunction() + vmlinuzEspPath + this.b2sum(vmlinuzFullPath));
        bootConfig.add(Config.SPACES + Limine.KERNEL_CMDLINE + " " + kernelCmdline);
        bootConfig.add("");  // Added a break line
        return bootConfig;
    }

    private List<String> createUkiBootConfig(List<String> kernelComments, String kernelCmdline, String ukiFileName) {
        String ukiFullPath = Utility.buildPath(config.espPath(), Config.DEFAULT_UKI_DIR_PATH, ukiFileName);
        ukiFullPath = Utility.correctCaseSensitivePath(ukiFullPath);

        String espPath = Utility.buildPath(config.espPath());
        assert ukiFullPath != null;
        String ukiEspPath = ukiFullPath.substring(espPath.length());

        List<String> bootConfig = new ArrayList<>();
        for (String comment : kernelComments) {
            if (!comment.isBlank()) {
                bootConfig.add(Config.SPACES + Limine.COMMENT + " " + comment);
            }
        }
        bootConfig.add(Config.SPACES + Limine.PROTOCOL + " " + Limine.PROTOCOL_EFI_CHAINLOAD);
        bootConfig.add(Config.SPACES + Limine.IMAGE_PATH + " " + config.pathFunction() + ukiEspPath + this.b2sum(ukiFullPath));
        bootConfig.add(Config.SPACES + Limine.KERNEL_CMDLINE + " " + kernelCmdline);
        bootConfig.add("");  // Added a break line
        return bootConfig;
    }

    private String b2sum(String absoluteFilePath) {
        if (Config.ENABLE_VERIFICATION) {
            String b2sum = Utility.computeBlake2(absoluteFilePath);
            if (b2sum.isEmpty()) {
                return "";
            } else {
                return Limine.HASH + b2sum;
            }
        } else {
            return "";
        }
    }

    private String getDefaultUkiFileName(String kernelName) {
        // Bugfix: Avoid using toLowerCase() on ukiFileName,
        // as Limine expects case-sensitive paths, but FAT32 is not case-sensitive, causing mismatches.
        String ukiFileName = kernelName;
        if (!kernelName.toLowerCase().endsWith(Config.UKI_FILE_SUFFIX)) {
            ukiFileName = ukiFileName + Config.UKI_FILE_SUFFIX;
        }
        if (Config.UKI_FILE_PREFIX != null && !Config.UKI_FILE_PREFIX.isBlank()) {
            if (!kernelName.startsWith(Config.UKI_FILE_PREFIX)) {
                ukiFileName = Config.UKI_FILE_PREFIX + "_" + ukiFileName;
            }
        } else {
            if (!kernelName.startsWith(config.machineID())) {
                ukiFileName = config.machineID() + "_" + ukiFileName;
            }
        }
        return ukiFileName;
    }

    public void remove(String kernelName, boolean isUKI) {
        if (kernelName == null || kernelName.isBlank()) {
            return;
        }
        // Remove the kernel name with all suffixes.
        String kernelFilePath;
        if (isUKI) {
            // UKI file path on the ESP
            kernelFilePath = Utility.buildPath(Config.DEFAULT_UKI_DIR_PATH) + File.separator + this.getDefaultUkiFileName(kernelName);
        } else {
            // kernel directory path on the ESP
            kernelFilePath = Utility.buildPath(config.machineID(), kernelName) + File.separator;
        }

        Iterator<TreeNode> it = this.targetOsNode.getNodes().iterator();
        while (it.hasNext()) {
            LimineEntry entry = new LimineEntry(it.next());
            if (isUKI) {
                if (entry.containsEfiPath(Limine.DEFAULT_PATH_FUNCTION.toString(), kernelFilePath)) {
                    it.remove();
                    this.isUpdateNeeded = true;
                    break;
                }
            } else {
                if (entry.containsKernelDirPath(Limine.DEFAULT_PATH_FUNCTION.toString(), kernelFilePath)) {
                    it.remove();
                    this.isUpdateNeeded = true;
                    break;
                }
            }
        }

        if (isUKI) {
            // Remove the UKI file.
            String ukiFilePath = Utility.buildPath(config.espPath(), Config.DEFAULT_UKI_DIR_PATH) + File.separator + this.getDefaultUkiFileName(kernelName);
            if (Utility.isFilePresent(ukiFilePath)) {
                Utility.deleteFile(ukiFilePath);
            }
        } else {
            // Remove the kernel directory
            String dirPath = Utility.buildPath(config.espPath(), config.machineID(), kernelName);
            if (Utility.isDirectoryPresent(dirPath)) {
                Utility.deleteDirectory(dirPath);
            }
        }
    }

    /**
     * Remove only a boot entry without removing kernel files
     */
    public void removeEntry(String kernelName) {
        if (kernelName == null || kernelName.isBlank()) {
            return;
        }
        String kernelNameKey = Limine.SUB_ENTRY_KEY + kernelName;
        List<TreeNode> nodes = this.targetOsNode.getNodes();

        for (int i = 0; i < nodes.size(); i++) {
            TreeNode bootNode = nodes.get(i);
            if (bootNode.getName().trim().equals(kernelNameKey)) {
                nodes.remove(i);
                this.isUpdateNeeded = true;
                i--; // Adjust the index after removal
            }
        }
    }


    /**
     * Sorts a list of boot entries based on a given order.
     * <p>
     * You can define the order using patterns.
     * Patterns can include a wildcard ("*"), which means "anything".
     * Patterns after "*" come first, and patterns before "*" come second.
     * Entries that don't match any pattern are grouped under "*".
     * <p>
     * Entries in the same group keep their original order,
     * but entries in wildcard ("*") groups are sorted alphabetically.
     *
     * @param entries   A list of boot entries to be sorted. The list will be changed directly.
     * @param bootOrder An array of patterns defining the desired boot order.
     *                  Patterns may include wildcards ("*").
     */
    private void sortEntriesByBootOrder(List<TreeNode> entries, String[] bootOrder) {
        // Separate patterns into groups: before and after the wildcard "*"
        List<String> patternsBeforeWildcard = new ArrayList<>();
        List<String> patternsAfterWildcard = new ArrayList<>();

        // Map to store grouped entries for each pattern (including a group for wildcard entries)
        Map<String, List<TreeNode>> groupedEntries = new LinkedHashMap<>();
        boolean wildcardFound = false;

        // Initialize groups based on the patterns provided in bootOrder
        for (String pattern : bootOrder) {
            groupedEntries.put(pattern, new ArrayList<>());
            if (pattern.trim().equals("*")) {
                wildcardFound = true;
                continue;
            }
            if (wildcardFound) {
                patternsAfterWildcard.add(pattern);
            } else {
                patternsBeforeWildcard.add(pattern);
            }
        }

        // Ensure a wildcard group exists even if "*" is missing in the bootOrder
        if (!wildcardFound) {
            groupedEntries.put("*", new ArrayList<>());
        }

        // Assign entries to the appropriate pattern group based on matching patterns
        for (TreeNode entry : entries) {
            boolean matched = false;

            // Match against patterns after the wildcard
            for (String pattern : patternsAfterWildcard) {
                String regex = pattern.replace("*", ".*"); // Convert wildcard to regex
                if (Pattern.matches(regex, entry.getCleanName())) {
                    groupedEntries.get(pattern).add(entry);
                    matched = true;
                    break;
                }
            }

            // Match against patterns before the wildcard, if not already matched
            if (!matched) {
                for (String pattern : patternsBeforeWildcard) {
                    String regex = pattern.replace("*", ".*"); // Convert wildcard to regex
                    if (Pattern.matches(regex, entry.getCleanName())) {
                        groupedEntries.get(pattern).add(entry);
                        matched = true;
                        break;
                    }
                }
            }

            // Add to the wildcard group if no pattern matched
            if (!matched) {
                groupedEntries.get("*").add(entry);
            }
        }

        // Rebuild the entries by appending grouped entries in boot order
        entries.clear();
        for (Map.Entry<String, List<TreeNode>> group : groupedEntries.entrySet()) {
            // Sort only for wildcard patterns
            if (Config.ENABLE_SORT && group.getKey().contains("*")) {
                group.getValue().sort(TreeNode::compareTo);
            }
            entries.addAll(group.getValue());
        }
    }
}
