package org.limine.entry.tool.processes;

import org.limine.entry.tool.formats.limine8.Limine;
import org.limine.entry.tool.objects.Config;
import org.limine.entry.tool.objects.EntryOptions;
import org.limine.entry.tool.objects.TreeNode;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;


public class LimineReader {

    private final String limineConfigPath;
    private final TreeNode rootNode;
    private final TreeNode targetOsNode;

    public LimineReader(Config config) throws IOException {

        this.limineConfigPath = Utility.buildPath(config.espPath(), Config.LIMINE_CONFIG_FILE);
        this.rootNode = new TreeNode("root", 0, null);

        if (!Utility.isFilePresent(limineConfigPath)) {
            Utility.infoMessage(limineConfigPath + " is created.");
            LimineWriter.createDefaultLimineConfigFile(limineConfigPath);
        }

        this.readLimineConfig(rootNode);
        TreeNode osNode = rootNode.findNodeByIDorName(config, 1);

        if (osNode == null && Config.ENABLE_OS_GENERATION) {
            // Create default OS entry
            this.targetOsNode = new TreeNode(Limine.ENTRY_KEY.toString().trim() + Limine.EXPAND + config.targetOs(), 1, "root");
            EntryOptions osEntryOptions = new EntryOptions()
                    .setMachineID(config.machineID())
                    .setPriority(Config.DEFAULT_ORDER_PRIORITY_VALUE)
                    .setEntryOverwrite(Config.DEFAULT_ENTRY_OVERWRITE);

            List<String> lines = List.of(
                    Limine.COMMENT + " " + targetOsNode.getCleanName(),
                    Limine.COMMENT + " " + osEntryOptions.buildEntryComment()
            );

            this.targetOsNode.getConfigLines().addAll(lines);
            int position = this.rootNode.findPositionByLowerPriority(Config.DEFAULT_ORDER_PRIORITY_VALUE);
            this.rootNode.addNode(position, this.targetOsNode);

        } else {
            this.targetOsNode = osNode;
        }
    }

    public TreeNode getRootNode() {
        return rootNode;
    }

    public TreeNode getTargetOsNode() {
        return targetOsNode;
    }

    private void readLimineConfig(TreeNode rootNode) throws IOException {
        List<String> lines = Files.readAllLines(Paths.get(limineConfigPath));
        this.parseLinesToTree(lines, rootNode, 0, lines.size());
    }


    private int parseLinesToTree(List<String> lines, TreeNode currentNode, int startIndex, int endIndex) {

        int index = startIndex;

        while (index < endIndex) {

            String line = lines.get(index);
            String trimLine = line.trim();
            if (trimLine.startsWith(Limine.ENTRY_KEY.toString())) {
                int depth = calculateDepth(trimLine);
                TreeNode childNode = new TreeNode(line, depth, currentNode.getName());
                currentNode.addNode(childNode);

                // Find the range for the child node
                int nextIndex = this.findNextNodeIndex(lines, index + 1, endIndex, depth);
                index = this.parseLinesToTree(lines, childNode, index + 1, nextIndex);

            } else {
                // Check if the line defines a macro
                MacroReplacer.parseMacro(line);
                currentNode.addConfigLine(line);
                index++;

            }
        }

        return index;
    }

    private int findNextNodeIndex(List<String> lines, int startIndex, int endIndex, int currentDepth) {

        for (int i = startIndex; i < endIndex; i++) {
            String line = lines.get(i).trim();
            if (line.startsWith(Limine.ENTRY_KEY.toString()) && calculateDepth(line) <= currentDepth) {
                return i;
            }
        }
        return endIndex;
    }

    private int calculateDepth(String line) {
        int depth = 0;
        while (depth < line.length() && line.startsWith(Limine.ENTRY_KEY.toString(), depth)) {
            depth++;
        }
        return depth;
    }
}
