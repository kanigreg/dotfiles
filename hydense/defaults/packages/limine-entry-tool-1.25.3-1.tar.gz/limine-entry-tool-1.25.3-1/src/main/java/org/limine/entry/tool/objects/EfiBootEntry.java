package org.limine.entry.tool.objects;

public record EfiBootEntry(String name, String gptUuid, String efiPath) {
}
