package org.limine.entry.tool.formats.limine8;

import org.limine.entry.tool.objects.TreeNode;
import org.limine.entry.tool.processes.Utility;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LimineEntry {

    private final Limine protocol;
    private final List<URI> uris = new ArrayList<>();
    private final List<Other> others = new ArrayList<>();

    public LimineEntry(TreeNode node) {
        Limine foundProtocol = null;

        for (String line : node.getConfigLines()) {
            String trimmed = line.trim();

            // 1. Protocol detection
            if (foundProtocol == null && trimmed.startsWith(Limine.PROTOCOL.toString())) {
                String protocolValue = trimmed.substring(Limine.PROTOCOL.toString().length()).trim();
                if (protocolValue.equals(Limine.PROTOCOL_EFI.toString())) {
                    foundProtocol = Limine.PROTOCOL_EFI;
                } else if (protocolValue.equals(Limine.PROTOCOL_LINUX.toString())) {
                    foundProtocol = Limine.PROTOCOL_LINUX;
                } else if (protocolValue.equals(Limine.PROTOCOL_EFI_CHAINLOAD.toString())) {
                    foundProtocol = Limine.PROTOCOL_EFI_CHAINLOAD;
                } else if (protocolValue.equals(Limine.PROTOCOL_UEFI.toString())) {
                    foundProtocol = Limine.PROTOCOL_UEFI;
                } else if (protocolValue.equals(Limine.PROTOCOL_LIMINE.toString())) {
                    foundProtocol = Limine.PROTOCOL_LIMINE;
                }
                continue;
            }

            // 2. URI detection for *PATH keys
            if (trimmed.startsWith(Limine.IMAGE_PATH.toString())
                    || trimmed.startsWith(Limine.MODULE_PATH.toString())
                    || trimmed.startsWith(Limine.KERNEL_PATH.toString())
                    || trimmed.startsWith(Limine.PATH.toString())) {

                // Determine which schema
                Limine pathProtocol;
                if (trimmed.startsWith(Limine.MODULE_PATH.toString())) {
                    pathProtocol = Limine.MODULE_PATH;
                } else if (trimmed.startsWith(Limine.IMAGE_PATH.toString())) {
                    pathProtocol = Limine.IMAGE_PATH;
                } else if (trimmed.startsWith(Limine.KERNEL_PATH.toString())) {
                    pathProtocol = Limine.KERNEL_PATH;
                } else {
                    pathProtocol = Limine.PATH;
                }

                String valuePart = trimmed.substring(pathProtocol.toString().length()).trim();

                // Extract function part (boot():, guid(...):, etc.)
                Pattern regex = Pattern.compile(Limine.PATH_RESOURCE_PATTERN.toString());
                Matcher match = regex.matcher(valuePart);
                String pathFunction = match.find() ? match.group() : "";

                if (pathFunction.isEmpty()) {
                    Utility.warnMessage("The URI is invalid", trimmed);
                    continue;
                }

                String pathPart = valuePart.substring(pathFunction.length()).trim();

                // Remove optional hash or comment
                String pathWithoutHash;
                String hashComment = "";
                int hashIndex = pathPart.indexOf(Limine.HASH.toString());
                if (hashIndex >= 0) {
                    pathWithoutHash = pathPart.substring(0, hashIndex).trim();
                    hashComment = pathPart.substring(hashIndex + Limine.HASH.toString().length()).trim();
                } else {
                    pathWithoutHash = pathPart;
                }

                uris.add(new URI(pathProtocol, pathFunction, pathWithoutHash, hashComment));
                continue;
            }

            // 3. Other configuration lines
            if (trimmed.startsWith(Limine.CMDLINE.toString())) {
                String value = trimmed.substring(Limine.CMDLINE.toString().length()).trim();
                others.add(new Other(Limine.CMDLINE, value));
                continue;
            }
            if (trimmed.startsWith(Limine.COMMENT.toString())) {
                String value = trimmed.substring(Limine.COMMENT.toString().length()).trim();
                others.add(new Other(Limine.COMMENT, value));
            }
        }

        this.protocol = foundProtocol;
    }

    public boolean isProtocolLinux() {
        return protocol == Limine.PROTOCOL_LINUX;
    }

    public boolean isProtocolEfi() {
        return protocol == Limine.PROTOCOL_EFI
                || protocol == Limine.PROTOCOL_UEFI
                || protocol == Limine.PROTOCOL_EFI_CHAINLOAD;
    }

    public boolean containsEfiPath(String pathArg, String efiFilePath) {
        if (!isProtocolEfi() || pathArg.isBlank()) {
            return false;
        }
        for (URI uri : uris) {
            if (uri.pathProtocol() == Limine.IMAGE_PATH || uri.pathProtocol() == Limine.PATH) {
                if (uri.pathFunction().contains(pathArg) && Utility.removeSurroundingSlashes(uri.path()).equalsIgnoreCase(Utility.removeSurroundingSlashes(efiFilePath))) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean containsKernelDirPath(String pathArg, String kernelFilePath) {
        if (!isProtocolLinux() || pathArg.isBlank()) {
            return false;
        }
        for (URI uri : uris) {
            if (uri.pathProtocol() == Limine.KERNEL_PATH || uri.pathProtocol() == Limine.PATH) {
                // Bugfix: Use File.separator to avoid ".../linux-lts/kernelName" being matched as ".../linux"
                if (uri.pathFunction().contains(pathArg) && Utility.startsWithIgnoreCase(Utility.removeSurroundingSlashes(uri.path()), Utility.removeSurroundingSlashes(kernelFilePath) + File.separator)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Represents a boot resource URI from a *PATH line.
     */
    public record URI(Limine pathProtocol, String pathFunction, String path, String other) {
    }

    /**
     * Represents other configuration key-value pairs such as comment or cmdline.
     */
    public record Other(Limine schema, String value) {
    }
}