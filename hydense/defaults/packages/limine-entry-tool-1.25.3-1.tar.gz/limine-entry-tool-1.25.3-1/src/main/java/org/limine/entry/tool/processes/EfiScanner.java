package org.limine.entry.tool.processes;

import org.limine.entry.tool.objects.ConsoleColor;
import org.limine.entry.tool.objects.EfiBootEntry;
import org.limine.entry.tool.objects.Output;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.limine.entry.tool.processes.Utility.infoMessage;


public class EfiScanner {

    private static final Scanner SCANNER = new Scanner(System.in);

    public static EfiBootEntry showEfiEntriesAndSelect() {
        List<EfiBootEntry> entries = getEfiBootEntries();
        if (entries.isEmpty()) {
            System.out.println(ConsoleColor.RED + "No EFI boot entries found." + ConsoleColor.RESET);
            return null;
        }
        infoMessage("Available EFI Boot Entries:");
        for (int i = 0; i < entries.size(); i++) {
            EfiBootEntry entry = entries.get(i);
            System.out.printf("%d: %s - GPT UUID: %s - EFI path: %s%n", i + 1, entry.name(), entry.gptUuid(), entry.efiPath());
        }
        System.out.printf(ConsoleColor.YELLOW + "Choose a boot entry number (1-%d) to add to Limine, or press [c] to cancel:%n" + ConsoleColor.RESET, entries.size());
        String input = SCANNER.nextLine().trim();
        if (input.equalsIgnoreCase("c")) {
            return null; // canceled
        }
        try {
            int selectedIndex = Integer.parseInt(input);
            if (selectedIndex < 1 || selectedIndex > entries.size()) {
                System.out.println(ConsoleColor.RED + "Invalid selection." + ConsoleColor.RESET);
                return null;
            }
            return entries.get(selectedIndex - 1); // Convert 1-based input to 0-based index
        } catch (NumberFormatException e) {
            System.out.println(ConsoleColor.RED + "Invalid selection." + ConsoleColor.RESET);
            return null;
        }
    }

    public static List<EfiBootEntry> getEfiBootEntries() {
        List<EfiBootEntry> efiEntries = new ArrayList<>();
        Output output = Utility.getTextFromCommand("efibootmgr", true, true);
        if (!output.isSuccess()) {
            return efiEntries;
        }
        // Regex pattern to match boot entries and ignore case for .efi extension
        Pattern regex = Pattern.compile("\\s+(.+?)\\s+HD\\(\\d+,GPT,([0-9a-fA-F-]+),[^)]+\\)(/\\S+(?i).efi)");
        for (String line : output.text()) {
            Matcher matcher = regex.matcher(line);
            if (matcher.find()) {
                String name = matcher.group(1).trim();
                String gptUuid = matcher.group(2).trim();
                String efiPath = matcher.group(3).trim();

                // Clean the EFI path by removing non-printable or invalid characters
                String validEfiPath = efiPath.replaceAll("[^\\x20-\\x7E]", "")
                        .replace("\\", "/") // Convert Windows-style backslashes to Unix-style slashes
                        .replace("//", "/");

                // Only add valid entries
                if (!validEfiPath.isEmpty()) {
                    efiEntries.add(new EfiBootEntry(name, gptUuid, validEfiPath));
                }
            }
        }
        return efiEntries;
    }
}