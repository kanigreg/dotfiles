package org.limine.entry.tool.objects;

import org.limine.entry.tool.formats.limine8.Limine;
import org.limine.entry.tool.processes.MacroReplacer;
import org.limine.entry.tool.processes.Utility;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

public class TreeNode implements Comparable<TreeNode> {

    private final List<String> configLines;
    private final LinkedList<TreeNode> nodes;
    private final int depth;
    private final String parentNodeName;
    private final String name, cleanName;
    private EntryOptions options;
    private boolean enableLineBreak;

    public TreeNode(String name, int depth, String parentNodeName) {
        this.name = name;
        this.cleanName = Utility.cleanName(name);
        this.configLines = new ArrayList<>();
        this.nodes = new LinkedList<>();
        this.depth = depth;
        this.parentNodeName = parentNodeName;
        this.enableLineBreak = false;
        this.options = null;
    }

    public void addConfigLine(String line) {
        this.configLines.add(line);
    }

    public void addNode(TreeNode node) {
        this.nodes.add(node);
    }

    public void addNode(int index, TreeNode node) {
        this.nodes.add(index, node);
    }

    public TreeNode findNodeByIDorName(Config config, int selectedDepth) {
        TreeNode node = findNodeByMachineID(config.machineID(), selectedDepth);
        if (node == null) {
            return findNodeByCleanName(config.targetOs(), config.machineID(), selectedDepth);
        } else {
            return node;
        }
    }

    public TreeNode findNodeByCleanName(String nodeName, String machineID, int selectedDepth) {
        if (nodeName == null) {
            return null;
        }
        if (nodeName.isBlank()) {
            return null;
        }
        if (0 >= selectedDepth) {
            if (Objects.equals(this.cleanName, nodeName)) {
                if (this.options != null && this.options.getMachineID() != null && machineID != null) {
                    if (this.options.getMachineID().isEmpty() || this.options.getMachineID().equals(machineID)) {
                        return this;
                    } else {
                        return null;
                    }
                } else {
                    return this;
                }
            }
            return null;
        }
        selectedDepth--;
        for (TreeNode node : nodes) {
            TreeNode result = node.findNodeByCleanName(nodeName, machineID, selectedDepth);
            if (result != null) {
                return result;
            }
        }
        return null;
    }

    public int findPositionByLowerPriority(int priority) {
        int position = 0; // 0 is the highest priority.
        for (TreeNode node : nodes) {
            if (priority > node.getOrCreateOptions().getPriority()) {
                return position;
            }
            position++;
        }
        return position; // The lowest priority.
    }

    public TreeNode findNodeByMachineID(String machineID, int selectedDepth) {
        if (0 >= selectedDepth) {
            if (machineID.equals(this.getOrCreateOptions().getMachineID())) {
                return this;
            }
            return null;
        }
        selectedDepth--;
        for (TreeNode node : nodes) {
            TreeNode result = node.findNodeByMachineID(machineID, selectedDepth);
            if (result != null) {
                return result;
            }
        }
        return null;
    }

    public boolean searchNodeByName(String nodeName, int selectedDepth) {
        if (0 >= selectedDepth) {
            return this.name.trim().equals(nodeName);
        }
        selectedDepth--;
        for (TreeNode node : nodes) {
            if (node.searchNodeByName(nodeName, selectedDepth)) {
                return true;
            }
        }
        return false;
    }

    public void printTree(String prefix) {
        System.out.println(prefix + name + " (Depth: " + depth + ", Parent: " + parentNodeName + ")");
        for (String line : configLines) {
            System.out.println(prefix + line);
        }
        for (TreeNode node : nodes) {
            node.printTree(prefix);
        }
    }

    @Override
    public String toString() {
        return "TreeNode{" + "name='" + name + '\'' + ", configBlock=" + configLines + ", depth=" + depth + ", parentNodeName='" + parentNodeName + '\'' + '}';
    }

    public List<String> getConfigLines() {
        return configLines;
    }

    public LinkedList<TreeNode> getNodes() {
        return nodes;
    }

    public boolean isEnableLineBreak() {
        return enableLineBreak;
    }

    public void setEnableLineBreak(boolean enableLineBreak) {
        this.enableLineBreak = enableLineBreak;
    }

    public String getName() {
        return name;
    }

    public String getCleanName() {
        return cleanName;
    }

    public EntryOptions getOrCreateOptions() {
        if (this.options == null) {
            this.options = new EntryOptions();
            for (String line : this.configLines) {
                if (line.trim().startsWith(Limine.COMMENT.toString())) {
                    this.options.parseComment(MacroReplacer.replaceMacros(line));
                }
            }
        }
        return options;
    }

    public void setOptions(EntryOptions options) {
        this.options = options;
    }

    @Override
    public int compareTo(TreeNode other) {
        return this.cleanName.compareTo(other.cleanName);
    }

}
