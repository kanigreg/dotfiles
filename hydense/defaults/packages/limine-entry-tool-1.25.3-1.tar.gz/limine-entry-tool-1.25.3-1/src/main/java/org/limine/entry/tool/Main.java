package org.limine.entry.tool;

import org.limine.entry.tool.objects.Config;
import org.limine.entry.tool.objects.ConsoleColor;
import org.limine.entry.tool.objects.EfiBootEntry;
import org.limine.entry.tool.objects.EntryOptions;
import org.limine.entry.tool.processes.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.limine.entry.tool.processes.Utility.*;


public class Main {

    public static void main(String[] args) throws IOException {
        // First, parse flags (e.g., --quiet, --help, --version) and store them
        List<String> remainingArgs = new ArrayList<>();
        String comment = "";
        EntryOptions entryOptions = new EntryOptions();
        boolean isArgComment = false, isArgPriority = false;
        for (String arg : args) {
            if (isArgComment) {
                if (arg.startsWith("--")) {
                    System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
                    printHelp();
                    return;
                } else {
                    comment = arg;
                    isArgComment = false; //Reset
                    continue;
                }
            }
            if (isArgPriority) {
                if (entryOptions.parseArg(arg, EntryOptions.Key.ORDER_PRIORITY)) {
                    isArgPriority = false; //Reset
                    continue;
                } else {
                    System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
                    printHelp();
                    return;
                }
            }
            switch (arg) {
                case "--quiet":
                    Config.QUIET = true;
                    break;
                case "--help":
                    printHelp();
                    return;
                case "--version":
                    System.out.println(ConsoleColor.GREEN + Utility.getVersion() + ConsoleColor.RESET);
                    return;
                case "--comment":
                    isArgComment = true;
                    break;
                case "--priority":
                    isArgPriority = true;
                    break;
                case "--overwrite":
                    entryOptions.setEntryOverwrite(true);
                    break;
                default:
                    remainingArgs.add(arg);
                    break;
            }
        }

        // Now, process the main command (first element of remainingArgs)
        if (remainingArgs.isEmpty()) {
            System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
            printHelp();
            return;
        }

        String command = remainingArgs.get(0);
        String kernelName;

        switch (command) {
            case "--add":
                if (remainingArgs.size() < 4) {
                    System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
                    printHelp();
                    return;
                }
                kernelName = remainingArgs.get(1);
                String initramfsPath = remainingArgs.get(2);
                String vmlinuzPath = remainingArgs.get(3);
                String suffixName = remainingArgs.size() == 5 ? remainingArgs.get(4) : "";
                add(kernelName, comment, entryOptions, initramfsPath, vmlinuzPath, suffixName);
                return;

            case "--add-uki":
                if (remainingArgs.size() < 3) {
                    System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
                    printHelp();
                    return;
                }
                kernelName = remainingArgs.get(1);
                String ukiPath = remainingArgs.get(2);
                addUki(kernelName, comment, entryOptions, ukiPath);
                return;

            case "--add-efi":
                if (remainingArgs.size() < 3) {
                    System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
                    printHelp();
                    return;
                }
                String efiName = remainingArgs.get(1);
                String efiPath = remainingArgs.get(2);
                addEfi(efiName, comment, entryOptions, efiPath);
                return;

            case "--remove":
                if (remainingArgs.size() != 2) {
                    System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
                    printHelp();
                    return;
                }
                kernelName = remainingArgs.get(1);
                remove(kernelName, false);
                return;

            case "--remove-uki":
                if (remainingArgs.size() != 2) {
                    System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
                    printHelp();
                    return;
                }
                kernelName = remainingArgs.get(1);
                remove(kernelName, true);
                return;

            case "--remove-entry":
                if (remainingArgs.size() != 2) {
                    System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
                    printHelp();
                    return;
                }
                kernelName = remainingArgs.get(1);
                removeEntry(kernelName);
                return;

            case "--remove-efi":
                if (remainingArgs.size() != 2) {
                    System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
                    printHelp();
                    return;
                }
                String filePath = remainingArgs.get(1);
                removeEfi(filePath);
                return;

            case "--remove-os":
                if (remainingArgs.size() != 2) {
                    System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
                    printHelp();
                    return;
                }
                String osNameOrMachineID = remainingArgs.get(1);
                removeOs(osNameOrMachineID);
                return;

            case "--remove-all":
                List<String> kernelNames = remainingArgs.stream().filter(arg -> !arg.startsWith("--")).toList();
                removeAll(kernelNames);
                return;

            case "--scan":
                scanEfiEntries();
                return;
            case "--get-cmdline":
                if (remainingArgs.size() != 2) {
                    System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
                    printHelp();
                    return;
                }
                kernelName = remainingArgs.get(1);
                ConfigReader configReader = new ConfigReader();
                Config config = configReader.readConfig();
                System.out.println(config.getKernelCmdline(kernelName));
                return;
            default:
                System.err.println(ConsoleColor.RED_BOLD + "Invalid arguments" + ConsoleColor.RESET);
                printHelp();
        }
    }

    private static void printHelp() {
        System.out.println("""
                Usage: limine-entry-tool [option] [--quiet]
                Options:
                       --add [kernel entry name] [path to initramfs] [path to vmlinuz] [any suffix name] --comment [any comment]
                       --add-uki [kernel entry name] [path to UKI file] --comment [any comment]
                       --add-efi [OS entry name] [path to EFI binary] --comment [any comment] --priority [number] --overwrite
                       --get-cmdline [kernel name]
                       --remove [kernel directory name]
                       --remove-uki [kernel file name]
                       --remove-entry [kernel entry name]
                       --remove-all [kernel name 1] [kernel name 2] [kernel name 3] ...
                       --remove-efi [path] : Remove an EFI boot entry that matches a specified bootable file path.
                       --remove-os [machine-ID or name] : Remove an OS entry matching a given machine-ID or OS name.
                       --scan : Scans available EFI entries for selection.
                       --version
                """);
    }

    private static void add(String kernelName, String comment, EntryOptions kernelEntryOptions, String initramfsPath, String vmlinuzPath, String suffixName) throws IOException {
        boolean isNameValid = Utility.isValidFat32Name(kernelName);
        if (!isNameValid) {
            exitWithError("Kernel name: '" + kernelName + "' is invalid due to FAT32 naming rules: Spaces and other special characters are not allowed.");
            return;
        }
        kernelName = kernelName.trim();
        suffixName = suffixName.trim();
        comment = comment.trim();

        ConfigReader configReader = new ConfigReader();
        Config config = configReader.readConfig();

        LimineReader limine = new LimineReader(config);
        LimineManager manager = new LimineManager(limine.getTargetOsNode(), config);
        manager.add(kernelName, comment, kernelEntryOptions, initramfsPath, vmlinuzPath, suffixName);

        // Save
        if (manager.isUpdateNeeded) {
            LimineWriter writer = new LimineWriter(config);
            writer.backup();
            writer.save(limine.getRootNode());
        }
    }

    private static void addUki(String kernelName, String comment, EntryOptions kernelEntryOptions, String ukiFilePath) throws IOException {
        if (!Utility.isSystemAmd64()) {
            exitWithError("Your system is not using x86_64 architecture");
        }
        if (!Utility.isSystemEfi()) {
            exitWithError("Your system is not using EFI mode");
        }

        boolean isNameValid = Utility.isValidFat32Name(kernelName);
        if (!isNameValid) {
            exitWithError("Kernel name: '" + kernelName + "' is invalid due to FAT32 naming rules: Spaces and other special characters are not allowed.");
            return;
        }
        kernelName = kernelName.trim();
        comment = comment.trim();

        ConfigReader configReader = new ConfigReader();
        Config config = configReader.readConfig();

        LimineReader limine = new LimineReader(config);
        LimineManager manager = new LimineManager(limine.getTargetOsNode(), config);
        manager.addUki(kernelName, comment, kernelEntryOptions, ukiFilePath);

        // Save
        if (manager.isUpdateNeeded) {
            LimineWriter writer = new LimineWriter(config);
            writer.backup();
            writer.save(limine.getRootNode());
        }
    }

    private static void addEfi(String efiName, String comment, EntryOptions kernelEntryOptions, String efiFilePath) throws IOException {
        if (!Utility.isSystemAmd64()) {
            exitWithError("Your system is not using x86_64 architecture");
            return;
        }
        if (!Utility.isSystemEfi()) {
            exitWithError("Your system is not using EFI mode");
            return;
        }

        efiName = efiName.trim();
        comment = comment.trim();
        efiFilePath = efiFilePath.trim();

        ConfigReader configReader = new ConfigReader();
        Config config = configReader.readConfig();
        Config.ENABLE_OS_GENERATION = false;
        LimineReader limine = new LimineReader(config);
        boolean isUpdateNeeded = LimineManager.merge(limine.getRootNode(), efiName, comment, kernelEntryOptions, efiFilePath, config);

        // Save
        if (isUpdateNeeded) {
            LimineWriter writer = new LimineWriter(config);
            writer.backup();
            writer.save(limine.getRootNode());
        }
    }


    private static void remove(String kernelName, boolean isUKI) throws IOException {
        boolean isNameValid = Utility.isValidFat32Name(kernelName);
        if (!isNameValid) {
            exitWithError("Kernel name: '" + kernelName + "' is invalid due to FAT32 naming rules: Spaces and other special characters are not allowed.");
            return;
        }

        ConfigReader configReader = new ConfigReader();
        Config config = configReader.readConfig();

        LimineReader limine = new LimineReader(config);
        LimineManager manager = new LimineManager(limine.getTargetOsNode(), config);
        manager.remove(kernelName.trim(), isUKI);

        // Save
        if (manager.isUpdateNeeded) {
            LimineWriter writer = new LimineWriter(config);
            writer.backup();
            writer.save(limine.getRootNode());
        }
    }

    /**
     * Remove only a boot entry without removing kernel files
     */
    private static void removeEntry(String kernelName) throws IOException {
        ConfigReader configReader = new ConfigReader();
        Config config = configReader.readConfig();

        LimineReader limine = new LimineReader(config);
        LimineManager manager = new LimineManager(limine.getTargetOsNode(), config);
        manager.removeEntry(kernelName.trim());

        // Save
        if (manager.isUpdateNeeded) {
            LimineWriter writer = new LimineWriter(config);
            writer.backup();
            writer.save(limine.getRootNode());
        }
    }

    private static void removeAll(List<String> kernelNames) throws IOException {
        ConfigReader configReader = new ConfigReader();
        Config config = configReader.readConfig();
        LimineReader limine = new LimineReader(config);
        LimineManager manager = new LimineManager(limine.getTargetOsNode(), config);
        for (String kernelName : kernelNames) {
            boolean isNameValid = Utility.isValidFat32Name(kernelName);
            if (isNameValid) {
                manager.remove(kernelName.trim(), true);
                manager.remove(kernelName.trim(), false);
            } else {
                errorMessage("Kernel name: '" + kernelName + "' is invalid due to FAT32 naming rules: Spaces and other special characters are not allowed.");
            }
        }
        // Save
        if (manager.isUpdateNeeded) {
            LimineWriter writer = new LimineWriter(config);
            writer.backup();
            writer.save(limine.getRootNode());
        }
    }

    /**
     * Remove an EFI boot entry
     */
    private static void removeEfi(String efiFilePath) throws IOException {
        ConfigReader configReader = new ConfigReader();
        Config config = configReader.readConfig();
        Config.ENABLE_OS_GENERATION = false;
        LimineReader limine = new LimineReader(config);
        boolean isUpdateNeeded = LimineManager.removeEfi(limine.getRootNode(), efiFilePath, config);
        // Save
        if (isUpdateNeeded) {
            LimineWriter writer = new LimineWriter(config);
            writer.backup();
            writer.save(limine.getRootNode());
        }
    }

    /**
     * Remove an OS entry
     */
    private static void removeOs(String osNameOrMachineID) throws IOException {
        ConfigReader configReader = new ConfigReader();
        Config config = configReader.readConfig();
        Config.ENABLE_OS_GENERATION = false;
        LimineReader limine = new LimineReader(config);
        boolean isUpdateNeeded = LimineManager.removeOs(limine.getRootNode(), osNameOrMachineID, config);
        // Save
        if (isUpdateNeeded) {
            LimineWriter writer = new LimineWriter(config);
            writer.backup();
            writer.save(limine.getRootNode());
        }
    }

    private static void scanEfiEntries() throws IOException {
        boolean isSuccess = true;
        EfiBootEntry selectedEntry = EfiScanner.showEfiEntriesAndSelect();
        if (selectedEntry != null) {
            Config.QUIET = true;
            EntryOptions options = new EntryOptions().setPriority(20).setEntryOverwrite(true);
            String mountPoint = Utility.getMountPoint(selectedEntry.gptUuid());
            if (mountPoint.isEmpty()) {
                String tempMountPoint = "/run/let";
                Utility.ensureDirectoryExists(tempMountPoint);
               if (Utility.runCommand("mount /dev/disk/by-partuuid/" + selectedEntry.gptUuid() + " " + tempMountPoint, false, true)) {
                   String fs = Utility.getFileSystemType(tempMountPoint, true);
                   if ("vfat".equalsIgnoreCase(fs) || "iso9660".equalsIgnoreCase(fs)) {
                       addEfi(selectedEntry.name(), selectedEntry.name(), options, tempMountPoint + selectedEntry.efiPath());
                   } else {
                       isSuccess = false;
                       warnMessage("Limine does not support the filesystem:", fs + " on the boot partition");
                   }
                   Utility.runCommand("umount " + tempMountPoint, false, true);
               } else {
                   isSuccess = false;
               }
            } else {
                String fs = Utility.getFileSystemType(mountPoint, true);
                if ("vfat".equalsIgnoreCase(fs) || "iso9660".equalsIgnoreCase(fs)) {
                    addEfi(selectedEntry.name(), selectedEntry.name(), options, mountPoint + selectedEntry.efiPath());
                } else {
                    isSuccess = false;
                    warnMessage("Limine does not support the filesystem:", fs + " on the boot partition");
                }
            }
            Config.QUIET = false;
            if (isSuccess) {
                infoMessage("EFI entry added to Limine:", "\"" + selectedEntry.name() + "\", guid(" + selectedEntry.gptUuid() + "):" + selectedEntry.efiPath());
            }
        }
    }
}